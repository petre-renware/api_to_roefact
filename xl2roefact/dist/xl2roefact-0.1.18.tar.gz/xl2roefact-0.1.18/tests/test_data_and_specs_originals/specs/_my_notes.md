
# Note si observatii la diversele documente din `specs/`

[TOC]



## Specificatiile facturii electronice format `XML`

* [x] (piu 231106) in doc `SR-EN-16931-12017.pdf` __pagina 32__ contine _modelul de date facturii_ (**downloaded as `ModelFactura_pg32.pdf`**)
* ...

