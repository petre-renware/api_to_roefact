"""xl2roefact in-package designed to implement **data layer**

* Issued: 2024 March
* Author: Petre Iordanescu, petre.iordanescu@gmail.com
* (c) RENware Software Systems
"""
