<small markdown=1>**Copyright (C) RENware Software Solution**</small>

[TOC]

# How to use `xl2roefact` application


## General rules

-#TODO plan:
- install the apllication & first setup (use permanently on this computer && offline/no-internet usage)
- directory `invoice_files/` and why is recommended to use it (diseminare fisiere perosnale de cele ale aplicatiei, ...)
- configuration items and how change them in file `config_settings.py`




## Delivered template usage

-#TODO plan:
- write about delivered template things like:
	- what is good for, type of invoices and their "complexity" alllowed
	- possible usage of "special" items, for example with "Accize" or other special taxes
	- how right-setup currency
	- about calendaristic "invoice issue date"




## Usage of other invoice excel files

-#TODO plan:
- write rules used in `rdinv()` module to corectly recognize Excel data and make JSON invoice file


